#!/bin/bash

while true; do
    socat -dd TCP4-LISTEN:20001,reuseaddr,fork,keepalive exec:./run.sh,end-close
done
