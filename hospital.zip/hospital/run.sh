#!/bin/sh

stdbuf -i0 -o0 -e0 timeout 120 ./Hospital
#strace -f ./rabbit.elf
