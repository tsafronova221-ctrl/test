import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from functools import wraps
from database import db, Group, Student, Lab, LabSession, LabResult, Test, User
from datetime import datetime, timedelta
import json

def format_number(value):
    """Форматирование числа: целые как целые, дробные с 1 знаком после запятой"""
    if value is None:
        return "0"
    float_val = float(value)
    if float_val == int(float_val):
        return str(int(float_val))
    return f"{float_val:.1f}"

def calculate_penalty(weeks_late, group=None):
    """
    Рассчитывает штраф за просрочку в зависимости от типа группы
    
    ФСФФ обычные: 1 нед = -1, 2 нед = -2, >2 нед = -2.5
    КИ-24-01 и КТ-23-04: 1 нед = -1, 2 нед = -2, >2 нед = -3
    ТВВП: 1 нед = -1, 2 нед = -3, >2 нед = -5
    """
    if weeks_late == 0:
        return 0
    
    # Если группа не передана, используем стандартные правила ФСФФ
    if group is None:
        if weeks_late == 1:
            return 1
        elif weeks_late == 2:
            return 2
        else:
            return 2.5
    
    # Определяем тип группы
    if group.type == 'РИАС':
        # ТВВП: 1 нед = -1, 2 нед = -3, >2 нед = -5
        if weeks_late == 1:
            return 2
        elif weeks_late == 2:
            return 4
        else:  # >2 недель
            return 5
    elif (group.name == 'КИ-24-01' and group.course == 'КИ') or (group.name == 'КТ-23-04' and group.course == 'КТ'):
        # КИ-24-01 и КТ-23-04: 1 нед = -1, 2 нед = -2, >2 нед = -3
        if weeks_late == 1:
            return 1
        elif weeks_late == 2:
            return 2
        else:  # >2 недель
            return 3
    else:
        # Остальные ФСФФ: 1 нед = -1, 2 нед = -2, >2 нед = -2.5
        if weeks_late == 1:
            return 1
        elif weeks_late == 2:
            return 2
        else:  # >2 недель
            return 2.5

def get_lab_component_maxes(group):
    """Возвращает максимальные баллы для компонентов лабы в зависимости от группы"""
    if group.type == 'РИАС':
        # ТВВП: техническая 4, отчет 4, защита 2
        return {'technical': 4, 'report': 4, 'defense': 2}
    elif group.type == 'КАФС':
        # КАФС: техническая 2, отчет 2, защита 1
        return {'technical': 2, 'report': 2, 'defense': 1}
    elif (group.name == 'КИ-24-01' and group.course == 'КИ') or (group.name == 'КТ-23-04' and group.course == 'КТ'):
        # КИ-24-01 и КТ-23-04: техническая 3, отчет 2, защита 1
        return {'technical': 3, 'report': 2, 'defense': 1}
    else:
        # Остальные ФСФФ: техническая 2, отчет 2, защита 1
        return {'technical': 2, 'report': 2, 'defense': 1}

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///lab_manager.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or os.urandom(24)

# Регистрируем фильтры для шаблонов
app.jinja_env.filters['format_number'] = format_number
app.jinja_env.globals.update(calculate_penalty=calculate_penalty)
app.jinja_env.globals.update(get_lab_component_maxes=get_lab_component_maxes)

db.init_app(app)

# Настройка Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Пожалуйста, войдите в систему для доступа к этой странице.'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Декоратор для проверки прав администратора
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'admin':
            flash('Доступ запрещен. Требуются права администратора.', 'error')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            groups = Group.query.all()
            return render_template('index.html', groups=groups)
        else:
            # Для студента - перенаправляем на страницу с его результатами
            return redirect(url_for('student_grades'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            flash(f'Добро пожаловать, {username}!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        else:
            flash('Неверное имя пользователя или пароль', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('login'))

@app.route('/student/grades')
@login_required
def student_grades():
    if current_user.role != 'student':
        flash('Эта страница доступна только студентам', 'error')
        return redirect(url_for('index'))
    
    student = Student.query.get(current_user.student_id)
    if not student:
        flash('Профиль студента не найден', 'error')
        return redirect(url_for('index'))
    
    group = Group.query.get(student.group_id)
    labs = Lab.query.filter_by(group_id=group.id).order_by(Lab.number).all()
    
    # Собираем результаты по лабораторным работам
    lab_results = []
    for lab in labs:
        result = LabResult.query.filter_by(student_id=student.id, lab_id=lab.id).first()
        lab_results.append({
            'lab': lab,
            'result': result
        })
    
    # Собираем результаты по контрольным работам
    test_scores = student.get_test_scores_dict()
    tests_data = []
    tests = Test.query.filter_by(group_id=group.id).all()
    for test in tests:
        test_data = test_scores.get(str(test.id), {})
        tests_data.append({
            'test': test,
            'score': test_data.get('score', 0),
            'date': test_data.get('date', ''),
            'notes': test_data.get('notes', '')
        })
    
    # Считаем итоговые баллы
    lab_total = 0
    for item in lab_results:
        if item['result']:
            weeks_late = item['result'].deadline_missed_weeks
            penalty = calculate_penalty(weeks_late, group)
            lab_total += (item['result'].technical_score + item['result'].report_score + 
                         item['result'].defense_score - penalty)
    
    test_total = sum([float(t['score']) for t in tests_data if t['score']])
    total_score = lab_total + test_total
    
    # Рассчитываем максимальные баллы
    # Для контрольных
    if group.type == 'ФСФФ':
        max_test_score = sum([test.max_score for test in tests])  # 2 к.р. по 5 баллов = 10
    else:
        max_test_score = sum([test.max_score for test in tests])  # 2 к.р. по 10 баллов = 20
    
    # Для лабораторных
    max_lab_score = sum([lab.max_score for lab in labs])  # Сумма всех максимальных баллов за лабы
    
    max_total_score = max_lab_score + max_test_score
    percentage = (total_score / max_total_score * 100) if max_total_score > 0 else 0
    
    return render_template('student_grades.html',
                         student=student,
                         group=group,
                         lab_results=lab_results,
                         tests_data=tests_data,
                         lab_total=lab_total,
                         test_total=test_total,
                         total_score=total_score,
                         percentage=percentage,
                         max_test_score=max_test_score,
                         max_total_score=max_total_score,
                         max_lab_score=max_lab_score)

# Маршруты для администратора
@app.route('/group/<int:group_id>')
@login_required
@admin_required
def group_detail(group_id):
    group = Group.query.get_or_404(group_id)
    labs = Lab.query.filter_by(group_id=group_id).order_by(Lab.number).all()
    students = Student.query.filter_by(group_id=group_id).order_by(Student.name).all()

    # Рассчитываем дедлайны для каждой лабы
    lab_deadlines = {}
    lab_sessions_count = {}

    for lab in labs:
        sessions = LabSession.query.filter_by(lab_id=lab.id).order_by(LabSession.date).all()
        lab_sessions_count[lab.id] = len(sessions)

        if len(sessions) >= lab.required_sessions:
            last_session = sessions[-1]
            deadline = last_session.date + timedelta(days=lab.deadline_days)
            lab_deadlines[lab.id] = deadline.strftime('%d.%m.%Y')

    # Получаем контрольные работы
    tests = Test.query.filter_by(group_id=group_id).order_by(Test.number).all()

    return render_template('group_detail.html',
                          group=group,
                          labs=labs,
                          students=students,
                          lab_deadlines=lab_deadlines,
                          lab_sessions_count=lab_sessions_count,
                          tests=tests,
                          timedelta=timedelta)

@app.route('/add_group', methods=['POST'])
@login_required
@admin_required
def add_group():
    name = request.form['name']
    course = request.form['course']
    subgroup = request.form.get('subgroup', '')
    lab_type = request.form['type']

    if not name or not course or not lab_type:
        flash('Заполните все обязательные поля: название группы, курс и тип')
        return redirect(url_for('index'))

    group = Group(name=name, course=course, subgroup=subgroup, type=lab_type)
    db.session.add(group)
    db.session.commit()

    # Создаем лабораторные работы для группы
    if lab_type == 'ФСФФ':
        # Проверяем, это группы КИ-24-01 или КТ-23-04
        if (name == 'КИ-24-01' and course == 'КИ') or (name == 'КТ-23-04' and course == 'КТ'):
            # 7 лаб для КИ-24-01 и КТ-23-04 по 2 пары каждая, каждая на 6 баллов
            for i in range(1, 8):
                lab = Lab(number=i, required_sessions=2, max_score=6.0, group_id=group.id)
                db.session.add(lab)
            
            # 2 контрольные работы по 9 баллов
            for i in range(1, 3):
                test = Test(number=i, max_score=9, group_id=group.id, test_type='kr')
                db.session.add(test)
        else:
            # 10 лаб для остальных ФСФФ по 2 пары каждая, каждая на 5 баллов
            for i in range(1, 11):
                lab = Lab(number=i, required_sessions=2, max_score=5.0, group_id=group.id)
                db.session.add(lab)
            
            # 2 контрольные работы по 5 баллов
            for i in range(1, 3):
                test = Test(number=i, max_score=5, group_id=group.id, test_type='kr')
                db.session.add(test)
    elif lab_type == 'КАФС':
        # 8 лаб по 2 пары каждая, каждая на 5 баллов
        for i in range(1, 9):
            lab = Lab(number=i, required_sessions=2, max_score=5.0, group_id=group.id)
            db.session.add(lab)
        
        # 2 контрольные работы по 5 баллов
        for i in range(1, 3):
            test = Test(number=i, max_score=5, group_id=group.id, test_type='kr')
            db.session.add(test)
        
        # 1 домашнее задание на 10 баллов
        dz = Test(number=1, max_score=10, group_id=group.id, test_type='dz')
        db.session.add(dz)
    else:
        # 8 лаб для ТВВП по 3 пары каждая, каждая на 10 баллов
        for i in range(1, 9):
            lab = Lab(number=i, required_sessions=3, max_score=10.0, group_id=group.id)
            db.session.add(lab)

        # 2 контрольные работы для ТВВП по 10 баллов
        for i in range(1, 3):
            test = Test(number=i, max_score=10, group_id=group.id, test_type='kr')
            db.session.add(test)

    db.session.commit()
    flash('Группа успешно добавлена!')
    return redirect(url_for('index'))

@app.route('/add_lab_session/<int:lab_id>', methods=['POST'])
@login_required
@admin_required
def add_lab_session(lab_id):
    lab = Lab.query.get_or_404(lab_id)

    # Проверяем, можно ли добавить ещё сессию
    current_sessions_count = LabSession.query.filter_by(lab_id=lab_id).count()
    if current_sessions_count >= lab.required_sessions:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': f'Нельзя добавить больше {lab.required_sessions} сессий для этой лабораторной работы'})
        flash(f'Нельзя добавить больше {lab.required_sessions} сессий для этой лабораторной работы')
        return redirect(url_for('group_detail', group_id=lab.group_id))

    date_str = request.form['date']
    instructor = request.form['instructor']
    completed_work = request.form['completed_work']
    notes = request.form.get('notes', '')

    if not date_str or not instructor or not completed_work:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Заполните все обязательные поля: дата, преподаватель и выполненная работа'})
        flash('Заполните все обязательные поля: дата, преподаватель и выполненная работа')
        return redirect(url_for('group_detail', group_id=lab.group_id))

    try:
        date = datetime.strptime(date_str, '%Y-%m-%d').date()
        session = LabSession(
            date=date,
            instructor=instructor,
            completed_work=completed_work,
            notes=notes,
            lab_id=lab_id
        )
        db.session.add(session)
        db.session.commit()

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': True, 'message': 'Сессия лабораторной работы успешно добавлена!'})

        flash('Сессия лабораторной работы успешно добавлена!')
    except ValueError:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Неверный формат даты. Используйте формат ГГГГ-ММ-ДД'})
        flash('Неверный формат даты. Используйте формат ГГГГ-ММ-ДД')

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': 'Сессия добавлена!'})

    return redirect(url_for('group_detail', group_id=lab.group_id))

@app.route('/edit_session/<int:session_id>', methods=['POST'])
@login_required
@admin_required
def edit_session(session_id):
    session = LabSession.query.get_or_404(session_id)

    date_str = request.form['date']
    instructor = request.form['instructor']
    completed_work = request.form['completed_work']
    notes = request.form.get('notes', '')

    if not date_str or not instructor or not completed_work:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Заполните все обязательные поля'})
        flash('Заполните все обязательные поля')
        return redirect(url_for('group_detail', group_id=session.lab.group_id))

    try:
        session.date = datetime.strptime(date_str, '%Y-%m-%d').date()
        session.instructor = instructor
        session.completed_work = completed_work
        session.notes = notes

        db.session.commit()

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': True, 'message': 'Сессия успешно обновлена!'})

        flash('Сессия успешно обновлена!')
    except ValueError:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Неверный формат даты'})
        flash('Неверный формат даты')

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': 'Сессия обновлена!'})

    return redirect(url_for('group_detail', group_id=session.lab.group_id))

@app.route('/delete_session/<int:session_id>', methods=['POST'])
@login_required
@admin_required
def delete_session(session_id):
    session = LabSession.query.get_or_404(session_id)
    group_id = session.lab.group_id

    db.session.delete(session)
    db.session.commit()

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': 'Сессия удалена!'})

    flash('Сессия удалена!')
    return redirect(url_for('group_detail', group_id=group_id))

@app.route('/update_student/<int:student_id>', methods=['POST'])
@login_required
@admin_required
def update_student(student_id):
    student = Student.query.get_or_404(student_id)

    win_machine = request.form.get('win_machine', '')
    proxmox_machine = request.form.get('proxmox_machine', '')
    notes = request.form.get('notes', '')

    student.win_machine = win_machine
    student.proxmox_machine = proxmox_machine
    student.notes = notes

    db.session.commit()

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': 'Данные студента обновлены!'})

    flash('Данные студента обновлены!')
    return redirect(url_for('group_detail', group_id=student.group_id))

@app.route('/update_lab_result', methods=['POST'])
@login_required
@admin_required
def update_lab_result():
    student_id = request.form['student_id']
    lab_id = request.form['lab_id']
    technical_score = request.form.get('technical_score', 0)
    report_score = request.form.get('report_score', 0)
    defense_score = request.form.get('defense_score', 0)
    submission_date_str = request.form.get('submission_date')
    notes = request.form.get('notes', '')

    # Проверяем только обязательные идентификаторы
    if not student_id or not lab_id:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Не указан студент или лабораторная работа'})
        flash('Не указан студент или лабораторная работа')
        lab = Lab.query.get(lab_id)
        return redirect(url_for('group_detail', group_id=lab.group_id))

    try:
        # Преобразуем в float с значениями по умолчанию
        technical_score = float(technical_score) if technical_score else 0.0
        report_score = float(report_score) if report_score else 0.0
        defense_score = float(defense_score) if defense_score else 0.0
        
        # Получаем лабу и группу для определения максимумов
        lab = Lab.query.get(lab_id)
        group = Group.query.get(lab.group_id)
        
        # Определяем максимальные баллы в зависимости от типа группы
        if group.type == 'РИАС':
            # ТВВП: техническая 4, отчет 4, защита 2
            max_technical = 4
            max_report = 4
            max_defense = 2
        elif (group.name == 'КИ-24-01' and group.course == 'КИ') or (group.name == 'КТ-23-04' and group.course == 'КТ'):
            # КИ-24-01 и КТ-23-04: техническая 3, отчет 2, защита 1
            max_technical = 3
            max_report = 2
            max_defense = 1
        else:
            # Остальные ФСФФ: техническая 2, отчет 2, защита 1
            max_technical = 2
            max_report = 2
            max_defense = 1

        # Проверяем диапазоны
        if technical_score < 0 or technical_score > max_technical:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': f'Техническая часть должна быть от 0 до {max_technical}'})
            flash(f'Техническая часть должна быть от 0 до {max_technical}')
            return redirect(url_for('group_detail', group_id=lab.group_id))

        if report_score < 0 or report_score > max_report:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': f'Отчёт должен быть от 0 до {max_report}'})
            flash(f'Отчёт должен быть от 0 до {max_report}')
            return redirect(url_for('group_detail', group_id=lab.group_id))

        if defense_score < 0 or defense_score > max_defense:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': f'Защита должна быть от 0 до {max_defense}'})
            flash(f'Защита должна быть от 0 до {max_defense}')
            return redirect(url_for('group_detail', group_id=lab.group_id))

        # Обработка даты сдачи (необязательное поле)
        submission_date = None
        if submission_date_str:
            try:
                submission_date = datetime.strptime(submission_date_str, '%Y-%m-%d').date()
                
                # Проверяем дату сдачи, если она указана
                min_date = datetime(2026, 2, 9).date()
                max_date = datetime(2026, 6, 20).date()

                if submission_date < min_date or submission_date > max_date:
                    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                        return jsonify({'success': False, 'message': 'Дата сдачи должна быть в диапазоне 09.02.2026 - 20.06.2026'})
                    flash('Дата сдачи должна быть в диапазоне 09.02.2026 - 20.06.2026')
                    lab = Lab.query.get(lab_id)
                    return redirect(url_for('group_detail', group_id=lab.group_id))
            except ValueError:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return jsonify({'success': False, 'message': 'Неверный формат даты'})
                flash('Неверный формат даты')
                lab = Lab.query.get(lab_id)
                return redirect(url_for('group_detail', group_id=lab.group_id))

        # Рассчитываем просрочку (только если есть сессии и указана дата сдачи)
        deadline_missed_weeks = 0
        if submission_date:  # Только если указана дата сдачи
            lab = Lab.query.get(lab_id)
            sessions = LabSession.query.filter_by(lab_id=lab_id).order_by(LabSession.date).all()

            if sessions:  # Если есть хотя бы одна сессия
                last_session = sessions[-1]
                deadline_date = last_session.date + timedelta(days=lab.deadline_days)

                if submission_date > deadline_date:
                    # Вычисляем разницу в неделях
                    days_late = (submission_date - deadline_date).days
                    deadline_missed_weeks = max(1, (days_late + 6) // 7)  # Округляем вверх до недель

        result = LabResult.query.filter_by(student_id=student_id, lab_id=lab_id).first()
        if not result:
            result = LabResult(student_id=student_id, lab_id=lab_id)
            db.session.add(result)

        result.technical_score = technical_score
        result.report_score = report_score
        result.defense_score = defense_score
        result.deadline_missed_weeks = deadline_missed_weeks
        result.submission_date = submission_date  # Может быть None
        result.notes = notes

        db.session.commit()

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': True, 'message': 'Результаты успешно обновлены!'})

        flash('Результаты успешно обновлены!')

    except ValueError:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Проверьте правильность введенных данных'})
        flash('Проверьте правильность введенных данных')

    lab = Lab.query.get(lab_id)

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': 'Результаты обновлены!'})

    return redirect(url_for('group_detail', group_id=lab.group_id))

@app.route('/add_test_score', methods=['POST'])
@login_required
@admin_required
def add_test_score():
    student_id = request.form['student_id']
    test_id = request.form['test_id']
    score = request.form.get('score', 0)
    test_date = request.form.get('test_date', '')
    notes = request.form.get('notes', '')

    try:
        score = float(score) if score else 0.0
        test = Test.query.get(test_id)

        if score < 0 or score > test.max_score:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': f'Оценка должна быть от 0 до {test.max_score}'})
            flash(f'Оценка должна быть от 0 до {test.max_score}')
            return redirect(url_for('group_detail', group_id=test.group_id))

        # Проверяем дату (необязательное поле)
        if test_date:
            try:
                date_obj = datetime.strptime(test_date, '%Y-%m-%d').date()
                min_date = datetime(2026, 2, 9).date()
                max_date = datetime(2026, 6, 20).date()

                if date_obj < min_date or date_obj > max_date:
                    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                        return jsonify({'success': False, 'message': 'Дата должна быть в диапазоне 09.02.2026 - 20.06.2026'})
                    flash('Дата должна быть в диапазоне 09.02.2026 - 20.06.2026')
                    return redirect(url_for('group_detail', group_id=test.group_id))

            except ValueError:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return jsonify({'success': False, 'message': 'Неверный формат даты'})
                flash('Неверный формат даты')
                return redirect(url_for('group_detail', group_id=test.group_id))

        # Обновляем или создаем результат
        student = Student.query.get(student_id)
        test_scores = student.get_test_scores_dict()

        test_scores[str(test_id)] = {
            'score': score,
            'date': test_date,
            'notes': notes
        }

        student.set_test_scores_dict(test_scores)

        db.session.commit()

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': True, 'message': 'Оценка за контрольную работу сохранена!'})

        flash('Оценка за контрольную работу сохранена!')

    except ValueError:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Введите корректное число'})
        flash('Введите корректное число')

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': 'Оценка сохранена!'})

    return redirect(url_for('group_detail', group_id=test.group_id))

@app.route('/update_test_score/<int:student_id>', methods=['POST'])
@login_required
@admin_required
def update_test_score(student_id):
    student = Student.query.get_or_404(student_id)

    test_id = request.form['test_id']
    score = request.form.get('score', 0)
    test_date = request.form.get('test_date', '')
    notes = request.form.get('notes', '')

    try:
        score = float(score) if score else 0.0
        test = Test.query.get(test_id)

        if score < 0 or score > test.max_score:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': f'Оценка должна быть от 0 до {test.max_score}'})
            flash(f'Оценка должна быть от 0 до {test.max_score}')
            return redirect(url_for('group_detail', group_id=test.group_id))

        # Проверяем дату (необязательное поле)
        if test_date:
            try:
                date_obj = datetime.strptime(test_date, '%Y-%m-%d').date()
                min_date = datetime(2026, 2, 9).date()
                max_date = datetime(2026, 6, 20).date()

                if date_obj < min_date or date_obj > max_date:
                    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                        return jsonify({'success': False, 'message': 'Дата должна быть в диапазоне 09.02.2026 - 20.06.2026'})
                    flash('Дата должна быть в диапазоне 09.02.2026 - 20.06.2026')
                    return redirect(url_for('group_detail', group_id=test.group_id))

            except ValueError:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return jsonify({'success': False, 'message': 'Неверный формат даты'})
                flash('Неверный формат даты')
                return redirect(url_for('group_detail', group_id=test.group_id))

        # Обновляем результат
        test_scores = student.get_test_scores_dict()

        test_scores[str(test_id)] = {
            'score': score,
            'date': test_date,
            'notes': notes
        }

        student.set_test_scores_dict(test_scores)

        db.session.commit()

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': True, 'message': 'Оценка за контрольную работу обновлена!'})

        flash('Оценка за контрольную работу обновлена!')

    except ValueError:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Введите корректное число'})
        flash('Введите корректное число')

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': 'Оценка обновлена!'})

    return redirect(url_for('group_detail', group_id=test.group_id))

@app.route('/get_final_scores/<int:group_id>')
@login_required
@admin_required
def get_final_scores(group_id):
    group = Group.query.get_or_404(group_id)
    students = Student.query.filter_by(group_id=group_id).order_by(Student.name).all()

    final_scores = []
    for student in students:
        # Считаем баллы за лабораторные
        lab_total = 0
        lab_results = LabResult.query.filter_by(student_id=student.id).all()
        for result in lab_results:
            penalty = calculate_penalty(result.deadline_missed_weeks, group)
            lab_total += (result.technical_score + result.report_score +
                         result.defense_score - penalty)

        # Считаем баллы за контрольные
        test_total = 0
        test_scores = student.get_test_scores_dict()
        for test_id, test_data in test_scores.items():
            if isinstance(test_data, dict) and 'score' in test_data:
                test_total += float(test_data['score'])
            else:
                # Для обратной совместимости со старым форматом
                test_total += float(test_data)

        # Итоговый балл (лабы + контрольные)
        total_score = lab_total + test_total

        final_scores.append({
            'student': student.name,
            'lab_total': lab_total,
            'test_total': test_total,
            'total_score': total_score
        })
    
    # Рассчитываем максимальные баллы для группы
    labs = Lab.query.filter_by(group_id=group_id).all()
    tests = Test.query.filter_by(group_id=group_id).all()
    
    max_lab_score = sum([lab.max_score for lab in labs])
    max_test_score = sum([test.max_score for test in tests])
    max_total_score = max_lab_score + max_test_score

    return jsonify({
        'scores': final_scores,
        'max_lab_score': max_lab_score,
        'max_test_score': max_test_score,
        'max_total_score': max_total_score
    })

@app.route('/get_session/<int:session_id>')
@login_required
@admin_required
def get_session(session_id):
    session = LabSession.query.get_or_404(session_id)
    return jsonify({
        'id': session.id,
        'date': session.date.strftime('%Y-%m-%d'),
        'instructor': session.instructor,
        'completed_work': session.completed_work,
        'notes': session.notes or ''
    })

@app.route('/get_test_score/<int:student_id>/<int:test_id>')
@login_required
@admin_required
def get_test_score(student_id, test_id):
    student = Student.query.get_or_404(student_id)
    test_scores = student.get_test_scores_dict()
    test_data = test_scores.get(str(test_id), {})

    return jsonify({
        'score': test_data.get('score', ''),
        'date': test_data.get('date', ''),
        'notes': test_data.get('notes', '')
    })

@app.route('/admin/create_users', methods=['GET', 'POST'])
@login_required
@admin_required
def create_users():
    if request.method == 'POST':
        students = Student.query.all()
        created_count = 0
        skipped_count = 0
        
        for student in students:
            # Создаем логин на основе имени студента
            base_username = ''.join(e for e in student.name.lower() if e.isalnum())
            username = base_username
            
            # Проверяем, нет ли уже пользователя для этого студента
            existing_user = User.query.filter_by(student_id=student.id).first()
            if existing_user:
                skipped_count += 1
                continue
            
            # Проверяем, нет ли пользователя с таким же логином
            counter = 1
            while User.query.filter_by(username=username).first():
                username = f"{base_username}{counter}"
                counter += 1
                if counter > 100:  # Защита от бесконечного цикла
                    flash(f'Не удалось создать логин для студента {student.name}', 'error')
                    break
            
            if counter <= 100:
                try:
                    user = User(username=username, role='student', student_id=student.id)
                    user.set_password('password123')  # Стандартный пароль, но не показываем его
                    db.session.add(user)
                    created_count += 1
                except Exception as e:
                    db.session.rollback()
                    flash(f'Ошибка при создании пользователя для {student.name}: {str(e)}', 'error')
        
        try:
            db.session.commit()
            if created_count > 0:
                flash(f'Создано {created_count} учетных записей студентов', 'success')
            if skipped_count > 0:
                flash(f'Пропущено {skipped_count} студентов (уже имеют учетные записи)', 'info')
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка при сохранении: {str(e)}', 'error')
        
        return redirect(url_for('create_users'))
    
    students = Student.query.all()
    users_info = []
    for student in students:
        user = User.query.filter_by(student_id=student.id).first()
        base_username = ''.join(e for e in student.name.lower() if e.isalnum())
        users_info.append({
            'student': student,
            'username': base_username,
            'actual_username': user.username if user else base_username,
            'has_account': user is not None
        })
    
    return render_template('create_users.html', users_info=users_info)
    
@app.route('/add_data')
@login_required
@admin_required
def add_data():
    return render_template('add_data.html')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        
        # Создаем администратора по умолчанию, если его нет
        admin = User.query.filter_by(username='Fake').first()
        if not admin:
            admin = User(username='Fake', role='admin')
            admin.set_password('!!FaKe!!_2@L0l_m@y')
            db.session.add(admin)
            db.session.commit()
            print('Создан администратор: admin / admin')
    
    app.run(host='0.0.0.0', port=1234, debug=True)
