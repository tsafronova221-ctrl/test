from app import app, db, Group, Lab, Student, Test

with app.app_context():
    # Создаем таблицы
    db.create_all()

    # Добавляем группы ФСФФ
    fsff_groups = [
        Group(name='КС-23-03', course='КС', type='ФСФФ'),
        Group(name='КС-23-18', course='КС', type='ФСФФ'),
        Group(name='КТ-23-04', course='КТ', type='ФСФФ'),
        Group(name='КС-22-03', course='КС', type='ФСФФ'),
        Group(name='КС-24-03', course='КС', type='ФСФФ'),
        Group(name='КТ-24-04', course='КТ', type='ФСФФ'),
        Group(name='КХ-24-05', course='КХ', type='ФСФФ'),
        Group(name='КИ-24-01', course='КИ', type='ФСФФ')  # Особая группа - 7 лаб по 7 баллов
    ]

    # Добавляем группы ТВВП
    rias_groups = [
        Group(name='КС-22-03', course='КС', type='РИАС'),
        Group(name='КТ-22-04', course='КТ', type='РИАС')
    ]

    # Сохраняем все группы
    for group in fsff_groups + rias_groups:
        db.session.add(group)

    db.session.commit()

    # Создаем лабораторные работы для каждой группы
    groups = Group.query.all()
    for group in groups:
        if group.type == 'ФСФФ':
            # Для групп КИ-24-01 и КТ-23-04 особые правила
            if (group.name == 'КИ-24-01' and group.course == 'КИ') or (group.name == 'КТ-23-04' and group.course == 'КТ'):
                # 7 лаб по 2 пары каждая, каждая на 6 баллов
                for i in range(1, 8):
                    lab = Lab(
                        number=i,
                        required_sessions=2,
                        max_score=6.0,
                        group_id=group.id
                    )
                    db.session.add(lab)

                # 2 контрольные по 9 баллов
                for i in range(1, 3):
                    test = Test(number=i, max_score=9, group_id=group.id)
                    db.session.add(test)
            else:
                # Для всех остальных ФСФФ групп - 10 лаб по 2 пары каждая, каждая на 5 баллов
                for i in range(1, 11):
                    lab = Lab(
                        number=i,
                        required_sessions=2,
                        max_score=5.0,
                        group_id=group.id
                    )
                    db.session.add(lab)

                # 2 контрольные по 5 баллов
                for i in range(1, 3):
                    test = Test(number=i, max_score=5, group_id=group.id)
                    db.session.add(test)
        else:
            # 8 лаб для ТВВП по 3 пары каждая, каждая на 10 баллов
            for i in range(1, 9):
                lab = Lab(
                    number=i,
                    required_sessions=3,
                    max_score=10.0,
                    group_id=group.id
                )
                db.session.add(lab)

            # 2 контрольные для ТВВП по 10 баллов
            for i in range(1, 3):
                test = Test(number=i, max_score=10, group_id=group.id)
                db.session.add(test)

    db.session.commit()
    print("База данных инициализирована!")
    print("\nСозданные группы:")
    print("\nФСФФ:")
    for group in Group.query.filter_by(type='ФСФФ').all():
        lab_count = Lab.query.filter_by(group_id=group.id).count()
        test_count = Test.query.filter_by(group_id=group.id).count()
        labs = Lab.query.filter_by(group_id=group.id).all()
        tests = Test.query.filter_by(group_id=group.id).all()
        lab_max = labs[0].max_score if labs else 0
        test_max = tests[0].max_score if tests else 0
        total_lab = lab_count * lab_max
        total_test = test_count * test_max
        if (group.name == 'КИ-24-01' and group.course == 'КИ') or (group.name == 'КТ-23-04' and group.course == 'КТ'):
            print(f"  {group.name} - {lab_count} лаб (по 2 пары, по {lab_max} баллов = {total_lab}), {test_count} к.р. (по {test_max} баллов = {total_test}) | ИТОГО: {total_lab + total_test}")
        else:
            print(f"  {group.name} - {lab_count} лаб (по 2 пары, по {lab_max} баллов = {total_lab}), {test_count} к.р. (по {test_max} баллов = {total_test}) | ИТОГО: {total_lab + total_test}")
    print("\nРИАС:")
    for group in Group.query.filter_by(type='РИАС').all():
        lab_count = Lab.query.filter_by(group_id=group.id).count()
        test_count = Test.query.filter_by(group_id=group.id).count()
        labs = Lab.query.filter_by(group_id=group.id).all()
        tests = Test.query.filter_by(group_id=group.id).all()
        lab_max = labs[0].max_score if labs else 0
        test_max = tests[0].max_score if tests else 0
        total_lab = lab_count * lab_max
        total_test = test_count * test_max
        subgroup_info = f" ({group.subgroup})" if group.subgroup else ""
        print(f"  {group.name}{subgroup_info} - {lab_count} лаб (по 3 пары, по {lab_max} баллов = {total_lab}), {test_count} к.р. (по {test_max} баллов = {total_test}) | ИТОГО: {total_lab + total_test}")
