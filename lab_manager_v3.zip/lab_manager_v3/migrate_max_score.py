"""
Скрипт миграции для добавления поля max_score в таблицу Lab
"""
from app import app, db, Lab, Group

def migrate_add_max_score():
    with app.app_context():
        # Обновляем все существующие лабораторные работы
        labs = Lab.query.all()
        
        for lab in labs:
            group = Group.query.get(lab.group_id)
            
            # Устанавливаем max_score в зависимости от группы
            if group.name == 'КИ-24-01' and group.course == 'КИ':
                lab.max_score = 7.0
            else:
                lab.max_score = 5.0
        
        db.session.commit()
        print("✅ Миграция завершена! Все лабораторные работы обновлены.")
        
        # Показываем результаты
        print("\nРезультаты миграции:")
        groups = Group.query.all()
        for group in groups:
            labs = Lab.query.filter_by(group_id=group.id).all()
            if labs:
                max_score = labs[0].max_score
                print(f"  {group.name} ({group.type}): {len(labs)} лаб x {max_score} баллов = {len(labs) * max_score} макс.")

if __name__ == '__main__':
    migrate_add_max_score()
