import os
from flask import Flask, render_template, request
from database import db, Group, Student, Lab, LabResult, Test
from datetime import datetime
import json

def format_number(value):
    """Форматирование числа: целые как целые, дробные с 1 знаком после запятой"""
    if value is None:
        return "0"
    float_val = float(value)
    if float_val == int(float_val):
        return str(int(float_val))
    return f"{float_val:.1f}"

def calculate_penalty(weeks_late, group=None):
    """
    Рассчитывает штраф за просрочку в зависимости от типа группы

    ФСФФ обычные: 1 нед = -1, 2 нед = -2, >2 нед = -2.5
    КИ-24-01 и КТ-23-04: 1 нед = -1, 2 нед = -2, >2 нед = -3
    ТВВП: 1 нед = -1, 2 нед = -3, >2 нед = -5
    """
    if weeks_late == 0:
        return 0

    # Если группа не передана, используем стандартные правила ФСФФ
    if group is None:
        if weeks_late == 1:
            return 1
        elif weeks_late == 2:
            return 2
        else:
            return 2.5

    # Определяем тип группы
    if group.type == 'РИАС':
        # ТВВП: 1 нед = -1, 2 нед = -3, >2 нед = -5
        if weeks_late == 1:
            return 2
        elif weeks_late == 2:
            return 4
        else:  # >2 недель
            return 5
    elif (group.name == 'КИ-24-01' and group.course == 'КИ') or (group.name == 'КТ-23-04' and group.course == 'КТ'):
        # КИ-24-01 и КТ-23-04: 1 нед = -1, 2 нед = -2, >2 нед = -3
        if weeks_late == 1:
            return 1
        elif weeks_late == 2:
            return 2
        else:  # >2 недель
            return 3
    else:
        # Остальные ФСФФ: 1 нед = -1, 2 нед = -2, >2 нед = -2.5
        if weeks_late == 1:
            return 1
        elif weeks_late == 2:
            return 2
        else:  # >2 недель
            return 2.5

def get_lab_passing_threshold(group):
    """
    Возвращает проходной балл для лабораторной работы в зависимости от группы

    Все группы ФСФФ: 2.5 балла (зачтено)
    КТ-23-04 и КИ-24-01: 3 балла
    ТВВП: 5 баллов
    """
    if group.type == 'РИАС':
        return 5.0  # Максимальный балл
    elif (group.name == 'КИ-24-01' and group.course == 'КИ') or (group.name == 'КТ-23-04' and group.course == 'КТ'):
        return 3.0
    else:
        return 2.5  # Все остальные группы ФСФФ

def get_test_passing_threshold(group):
    """
    Возвращает проходной балл для контрольной работы в зависимости от группы

    Все группы ФСФФ: 2.5 балла
    КТ-23-04 и КИ-24-01: 4.5 балла
    ТВВП: 5 баллов
    """
    if group.type == 'РИАС':
        return 5.0  # Максимальный балл
    elif (group.name == 'КИ-24-01' and group.course == 'КИ') or (group.name == 'КТ-23-04' and group.course == 'КТ'):
        return 4.5
    else:
        return 2.5  # Все остальные группы ФСФФ

def create_student_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///lab_manager.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or os.urandom(24)

    # Регистрируем фильтры для шаблонов
    app.jinja_env.filters['format_number'] = format_number
    app.jinja_env.globals.update(calculate_penalty=calculate_penalty)
    app.jinja_env.globals.update(get_lab_passing_threshold=get_lab_passing_threshold)
    app.jinja_env.globals.update(get_test_passing_threshold=get_test_passing_threshold)

    db.init_app(app)

    def is_lab_passed(lab_result, group):
        """
        Проверяет, сдана ли лабораторная работа.
        Условия зачета:
        - Техническая часть > 0
        - Отчёт > 0
        - Защита > 0
        - Итоговый балл >= проходного порога для группы

        Проходные баллы:
        - Все ФСФФ: 2.5 балла
        - КИ-24-01 и КТ-23-04: 3 балла
        - ТВВП: 5 баллов (максимальный)
        """
        if not lab_result:
            return False, 0, 0, 0

        # Получаем баллы
        tech_score = lab_result.technical_score
        report_score = lab_result.report_score
        defense_score = lab_result.defense_score

        # Проверяем, что все компоненты > 0
        if tech_score <= 0 or report_score <= 0 or defense_score <= 0:
            penalty = calculate_penalty(lab_result.deadline_missed_weeks, group)
            return False, tech_score + report_score + defense_score, lab_result.deadline_missed_weeks, 0

        # Считаем общую сумму
        total_score = tech_score + report_score + defense_score

        # Вычитаем просрочку по системе группы
        penalty = calculate_penalty(lab_result.deadline_missed_weeks, group)
        final_score = total_score - penalty

        # Получаем проходной порог для группы
        passing_threshold = get_lab_passing_threshold(group)

        # Зачет если итоговый балл >= проходного порога
        is_passed = final_score >= passing_threshold

        return is_passed, total_score, lab_result.deadline_missed_weeks, final_score

    def is_test_passed(test_score, group):
        """
        Проверяет, сдана ли контрольная работа.
        Условия зачета: балл >= проходного порога для группы

        Проходные баллы:
        - Все ФСФФ: 2.5 балла
        - КИ-24-01 и КТ-23-04: 4.5 балла
        - ТВВП: 5 баллов
        """
        try:
            score = float(test_score) if test_score else 0.0
            passing_threshold = get_test_passing_threshold(group)
            return score >= passing_threshold
        except (ValueError, TypeError):
            return False

    @app.route('/')
    def student_index():
        groups = Group.query.all()
        return render_template('student_index.html', groups=groups)

    @app.route('/group/<int:group_id>')
    def group_students(group_id):
        group = Group.query.get_or_404(group_id)
        students = Student.query.filter_by(group_id=group_id).order_by(Student.name).all()

        # Получаем лабораторные работы
        labs = Lab.query.filter_by(group_id=group_id).order_by(Lab.number).all()

        # Получаем контрольные работы
        tests = Test.query.filter_by(group_id=group_id).order_by(Test.number).all()

        # Получаем проходные баллы для группы
        lab_passing_threshold = get_lab_passing_threshold(group)
        test_passing_threshold = get_test_passing_threshold(group)

        # Собираем данные о статусах для каждого студента
        students_data = []
        for student in students:
            # Статусы лабораторных работ
            lab_statuses = []
            for lab in labs:
                result = LabResult.query.filter_by(student_id=student.id, lab_id=lab.id).first()
                is_passed, total_score, missed_weeks, final_score = is_lab_passed(result, group)
                status = 'зачет' if is_passed else 'незачет'

                # Добавляем информацию о просрочке
                deadline_info = ""
                if missed_weeks > 0:
                    penalty = calculate_penalty(missed_weeks, group)
                    penalty_str = format_number(penalty)
                    deadline_info = f" (-{penalty_str} балл)"

                lab_statuses.append({
                    'number': lab.number,
                    'status': status,
                    'deadline_info': deadline_info,
                    'result': result,
                    'total_score': total_score,
                    'final_score': final_score,
                    'missed_weeks': missed_weeks
                })

            # Статусы контрольных работ
            test_statuses = []
            test_scores = student.get_test_scores_dict()
            for test in tests:
                test_data = test_scores.get(str(test.id), {})
                score = test_data.get('score', 0)
                status = 'зачет' if is_test_passed(score, group) else 'незачет'
                test_statuses.append({
                    'number': test.number,
                    'status': status,
                    'score': score,
                    'max_score': test.max_score
                })

            students_data.append({
                'student': student,
                'lab_statuses': lab_statuses,
                'test_statuses': test_statuses
            })

        return render_template('student_group_view.html',
                             group=group,
                             students_data=students_data,
                             labs=labs,
                             tests=tests,
                             lab_passing_threshold=lab_passing_threshold,
                             test_passing_threshold=test_passing_threshold)

    @app.route('/student/<int:student_id>')
    def student_detail(student_id):
        student = Student.query.get_or_404(student_id)
        group = Group.query.get(student.group_id)

        # Получаем лабораторные работы
        labs = Lab.query.filter_by(group_id=group.id).order_by(Lab.number).all()

        # Получаем контрольные работы
        tests = Test.query.filter_by(group_id=group.id).order_by(Test.number).all()

        # Получаем проходные баллы для группы
        lab_passing_threshold = get_lab_passing_threshold(group)
        test_passing_threshold = get_test_passing_threshold(group)

        # Статусы лабораторных работ
        lab_statuses = []
        for lab in labs:
            result = LabResult.query.filter_by(student_id=student.id, lab_id=lab.id).first()
            is_passed, total_score, missed_weeks, final_score = is_lab_passed(result, group)
            status = 'зачет' if is_passed else 'незачет'

            # Детальная информация для страницы студента
            submission_info = "Не сдана"
            details_info = "Нет данных"
            deadline_info = ""
            score_info = ""

            if result:
                if result.submission_date:
                    submission_info = f"Сдана {result.submission_date.strftime('%d.%m.%Y')}"

                # Формируем информацию о баллах
                tech_score = result.technical_score
                report_score = result.report_score
                defense_score = result.defense_score

                # Форматируем баллы
                tech_str = format_number(tech_score)
                report_str = format_number(report_score)
                defense_str = format_number(defense_score)

                details_info = f"Техн.: {tech_str}/2, Отчёт: {report_str}/2, Защита: {defense_str}/1"

                # Информация о баллах с учетом просрочки
                if tech_score > 0 and report_score > 0 and defense_score > 0:
                    penalty = calculate_penalty(missed_weeks, group)
                    penalty_str = format_number(penalty)
                    total_str = format_number(total_score)
                    final_str = format_number(final_score)
                    passing_str = format_number(lab_passing_threshold)
                    score_info = f"Сумма: {total_str} - {penalty_str} (штраф) = {final_str}/5 (зачёт от {passing_str})"

                # Информация о просрочке
                if missed_weeks > 0:
                    penalty = calculate_penalty(missed_weeks, group)
                    penalty_str = format_number(penalty)
                    deadline_info = f" (+{missed_weeks} нед. просрочки, -{penalty_str} балл)"
                    submission_info += deadline_info

            lab_statuses.append({
                'number': lab.number,
                'status': status,
                'submission_info': submission_info,
                'details_info': details_info,
                'deadline_info': deadline_info,
                'score_info': score_info,
                'result': result,
                'total_score': total_score,
                'final_score': final_score,
                'missed_weeks': missed_weeks,
                'passing_threshold': lab_passing_threshold
            })

        # Статусы контрольных работ
        test_statuses = []
        test_scores = student.get_test_scores_dict()
        for test in tests:
            test_data = test_scores.get(str(test.id), {})
            score = test_data.get('score', 0)
            status = 'зачет' if is_test_passed(score, group) else 'незачет'
            test_date = test_data.get('date', '')

            date_info = "Не сдана"
            if test_date:
                date_info = f"Сдана {test_date}"

            # Форматируем балл для отображения
            score_display = format_number(score) if score else "0"

            test_statuses.append({
                'number': test.number,
                'status': status,
                'date_info': date_info,
                'score_display': score_display,
                'max_score': test.max_score,
                'passing_threshold': test_passing_threshold
            })

        # Считаем статистику
        passed_labs = len([lab for lab in lab_statuses if lab['status'] == 'зачет'])
        passed_tests = len([test for test in test_statuses if test['status'] == 'зачет'])

        # Проверяем, есть ли работы с просрочкой
        has_deadline_issues = any(lab['missed_weeks'] > 0 for lab in lab_statuses)

        return render_template('student_detail_view.html',
                             student=student,
                             group=group,
                             lab_statuses=lab_statuses,
                             test_statuses=test_statuses,
                             labs_count=len(labs),
                             tests_count=len(tests),
                             passed_labs=passed_labs,
                             passed_tests=passed_tests,
                             has_deadline_issues=has_deadline_issues,
                             lab_passing_threshold=lab_passing_threshold,
                             test_passing_threshold=test_passing_threshold)

    return app

if __name__ == '__main__':
    student_app = create_student_app()
    with student_app.app_context():
        db.create_all()
    student_app.run(host='0.0.0.0', port=5001, debug=True)
