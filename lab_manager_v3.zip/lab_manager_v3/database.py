from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import json

db = SQLAlchemy()

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='student')  # 'admin' или 'student'
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Group(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    course = db.Column(db.String(50), nullable=False)
    subgroup = db.Column(db.String(50), default='')
    type = db.Column(db.String(10), default='ФСФФ')  # ФСФФ или ТВВП
    labs = db.relationship('Lab', backref='group', lazy=True)
    students = db.relationship('Student', backref='group', lazy=True)
    tests = db.relationship('Test', backref='group', lazy=True)

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    win_machine = db.Column(db.String(50))
    proxmox_machine = db.Column(db.String(50))
    notes = db.Column(db.Text)
    group_id = db.Column(db.Integer, db.ForeignKey('group.id'), nullable=False)
    lab_results = db.relationship('LabResult', backref='student', lazy=True)
    test_scores = db.Column(db.Text, default='{}')  # JSON для хранения оценок за контрольные
    user = db.relationship('User', backref='student', uselist=False, lazy=True)

    def get_test_scores_dict(self):
        return json.loads(self.test_scores) if self.test_scores else {}

    def set_test_scores_dict(self, scores_dict):
        self.test_scores = json.dumps(scores_dict)

class Lab(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.Integer, nullable=False)
    required_sessions = db.Column(db.Integer, default=2)
    group_id = db.Column(db.Integer, db.ForeignKey('group.id'), nullable=False)
    sessions = db.relationship('LabSession', backref='lab', lazy=True)
    deadline_days = db.Column(db.Integer, default=7)
    max_score = db.Column(db.Float, default=5.0)  # Максимальный балл за лабу (5 для обычных, 7 для КИ-24-01)

class LabSession(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    instructor = db.Column(db.String(100), nullable=False)
    completed_work = db.Column(db.Text)
    notes = db.Column(db.Text)
    lab_id = db.Column(db.Integer, db.ForeignKey('lab.id'), nullable=False)

class LabResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    lab_id = db.Column(db.Integer, db.ForeignKey('lab.id'), nullable=False)
    technical_score = db.Column(db.Float, default=0.0)  # Изменено на Float для десятичных значений
    report_score = db.Column(db.Float, default=0.0)     # Изменено на Float для десятичных значений
    defense_score = db.Column(db.Float, default=0.0)    # Изменено на Float для десятичных значений
    submission_date = db.Column(db.Date)
    deadline_missed_weeks = db.Column(db.Integer, default=0)
    notes = db.Column(db.Text)

class Test(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.Integer, nullable=False)
    max_score = db.Column(db.Float, default=10.0)
    group_id = db.Column(db.Integer, db.ForeignKey('group.id'), nullable=False)
    test_type = db.Column(db.String(10), default='kr')  # 'kr' = контрольная работа, 'dz' = домашнее задание
