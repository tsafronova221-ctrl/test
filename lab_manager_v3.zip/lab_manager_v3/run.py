import threading
from app import app as main_app
from student_view import create_student_app

def run_main_app():
    main_app.run(host='0.0.0.0', port=1234, debug=False, use_reloader=False)

def run_student_app():
    student_app = create_student_app()
    student_app.run(host='0.0.0.0', port=5001, debug=False, use_reloader=False)

if __name__ == '__main__':
    print("Запуск основного приложения на порту 1234...")
    print("Запуск студенческого вида на порту 5001...")
    
    # Запускаем в отдельных потоках
    main_thread = threading.Thread(target=run_main_app)
    student_thread = threading.Thread(target=run_student_app)
    
    main_thread.daemon = True
    student_thread.daemon = True
    
    main_thread.start()
    student_thread.start()
    
    try:
        # Держим основной поток активным
        while True:
            pass
    except KeyboardInterrupt:
        print("\nОстановка приложений...")
