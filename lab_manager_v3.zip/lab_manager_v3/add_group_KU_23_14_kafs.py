"""
Скрипт для добавления группы КЮ-23-14 (КАФС) в существующую базу данных.

Создаёт:
  - Группу КЮ-23-14 типа КАФС
  - 8 лабораторных работ × 5 баллов (2 пары каждая)
  - 2 контрольные работы × 5 баллов
  - 1 домашнее задание × 10 баллов

Запуск:
    python add_group_KU_23_14_kafs.py
"""

import sqlite3
import os
import sys

# ── Сначала делаем миграцию БД (добавляем колонку test_type, если её нет) ──────

db_path = os.path.join(os.path.dirname(__file__), 'instance', 'lab_manager.db')

if not os.path.exists(db_path):
    print(f"❌ База данных не найдена: {db_path}")
    sys.exit(1)

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Миграция: колонка test_type
cursor.execute("PRAGMA table_info(test)")
columns = [row[1] for row in cursor.fetchall()]
if 'test_type' not in columns:
    cursor.execute("ALTER TABLE test ADD COLUMN test_type VARCHAR(10) DEFAULT 'kr'")
    conn.commit()
    print("✅ Миграция: колонка test_type добавлена в таблицу test")
else:
    print("✅ Миграция не нужна: колонка test_type уже есть")

conn.close()

# ── Теперь работаем через Flask/SQLAlchemy ─────────────────────────────────────

from app import app, db
from database import Group, Lab, Test

GROUP_NAME   = 'КЮ-23-14'
GROUP_COURSE = 'КЮ'
GROUP_TYPE   = 'КАФС'

with app.app_context():

    # Проверяем, не существует ли уже такая группа
    existing = Group.query.filter_by(name=GROUP_NAME, course=GROUP_COURSE).first()
    if existing:
        print(f"⚠️  Группа {GROUP_NAME} (курс {GROUP_COURSE}) уже существует (id={existing.id}).")
        print("   Если хотите пересоздать — удалите группу вручную и запустите скрипт снова.")
        sys.exit(0)

    # ── Создаём группу ──────────────────────────────────────────────────────────
    group = Group(name=GROUP_NAME, course=GROUP_COURSE, subgroup='', type=GROUP_TYPE)
    db.session.add(group)
    db.session.flush()   # получаем group.id до commit-а
    print(f"✅ Группа {GROUP_NAME} ({GROUP_TYPE}) создана, id={group.id}")

    # ── 8 лабораторных работ × 5 баллов ────────────────────────────────────────
    for i in range(1, 9):
        lab = Lab(number=i, required_sessions=2, max_score=5.0, group_id=group.id)
        db.session.add(lab)
    print("✅ Добавлено 8 лабораторных работ (макс. 5 баллов каждая, 2 пары)")

    # ── 2 контрольные работы × 5 баллов ────────────────────────────────────────
    for i in range(1, 3):
        kr = Test(number=i, max_score=5.0, group_id=group.id, test_type='kr')
        db.session.add(kr)
    print("✅ Добавлено 2 контрольные работы (макс. 5 баллов каждая)")

    # ── 1 домашнее задание × 10 баллов ─────────────────────────────────────────
    dz = Test(number=1, max_score=10.0, group_id=group.id, test_type='dz')
    db.session.add(dz)
    print("✅ Добавлено 1 домашнее задание (макс. 10 баллов)")

    db.session.commit()

    # ── Итоговая сводка ─────────────────────────────────────────────────────────
    labs  = Lab.query.filter_by(group_id=group.id).count()
    tests = Test.query.filter_by(group_id=group.id, test_type='kr').count()
    dzs   = Test.query.filter_by(group_id=group.id, test_type='dz').count()
    max_labs  = sum(l.max_score for l in Lab.query.filter_by(group_id=group.id).all())
    max_tests = sum(t.max_score for t in Test.query.filter_by(group_id=group.id).all())

    print()
    print("═" * 50)
    print(f"🎉 Группа {GROUP_NAME} ({GROUP_TYPE}) успешно создана!")
    print(f"   Лаб. работ : {labs}  (итого макс. {max_labs:.0f} баллов)")
    print(f"   К. работ   : {tests}")
    print(f"   ДЗ         : {dzs}")
    print(f"   Макс. балл за КР+ДЗ : {max_tests:.0f}")
    print(f"   Общий макс.: {max_labs + max_tests:.0f} баллов")
    print("═" * 50)
    print()
    print("👉 Следующий шаг: добавьте студентов через веб-интерфейс")
    print("   или создайте скрипт add_students_KU_23_14.py по образцу других групп.")

if __name__ == '__main__':
    pass   # весь код выполняется при импорте модуля
