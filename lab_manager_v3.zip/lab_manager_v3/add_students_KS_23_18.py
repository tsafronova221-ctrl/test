from app import app, db, Student, Group

def add_students_to_group():
    with app.app_context():
        # Показываем все группы
        groups = Group.query.all()
        
        if not groups:
            print("❌ Группы не найдены! Сначала создайте группу через веб-интерфейс.")
            return
        
        print("📋 Доступные группы:")
        for i, group in enumerate(groups, 1):
            subgroup_info = f" ({group.subgroup})" if group.subgroup else ""
            print(f"{i}. {group.name}{subgroup_info} - {group.type}")
        
        # Выбор группы
        try:
            choice = int(input("\n🎯 Выберите номер группы для добавления студентов: ")) - 1
            if choice < 0 or choice >= len(groups):
                print("❌ Неверный выбор!")
                return
            
            selected_group = groups[choice]
            print(f"\n✅ Выбрана группа: {selected_group.name}")
            
        except ValueError:
            print("❌ Введите корректный номер!")
            return
        
        # Список студентов
        students_list = [
            "Андреева Алина Романовна",
            "Бережная Полина Александровна",
            "Ваулин Степан Евгеньевич",
            "Долгова Любовь Владимировна",
            "Исаева Яна Константиновна",
            "Калинин Сергей Юрьевич",
            "Костин Никита Андреевич",
            "Куреев Максим Сергеевич",
            "Мирчевски Кристина Далиборовна",
            "Сеидов Мирсамед Сеид-Азямович",
            "Смирнов Роман Викторович",
            "Сутырин Максим Александрович",
            "Хорошилов Лев Геннадьевич",
            "Шагалиев Тимур Салаватович"
        ]
        
        print(f"\n👥 Добавляем {len(students_list)} студентов в группу {selected_group.name}...")
        
        # Добавляем студентов
        added_count = 0
        for student_name in students_list:
            existing = Student.query.filter_by(name=student_name, group_id=selected_group.id).first()
            if not existing:
                student = Student(name=student_name, group_id=selected_group.id)
                db.session.add(student)
                added_count += 1
                print(f"✅ Добавлен: {student_name}")
            else:
                print(f"ℹ️ Уже существует: {student_name}")
        
        db.session.commit()
        print(f"\n🎉 Готово! Добавлено {added_count} новых студентов в группу {selected_group.name}")
        print(f"📊 Всего студентов в группе: {Student.query.filter_by(group_id=selected_group.id).count()}")

if __name__ == '__main__':
    add_students_to_group()
