"""
Миграция: добавить поле test_type в таблицу test
Запустить один раз: python migrate_test_type.py
"""
import sqlite3
import os

db_path = os.path.join(os.path.dirname(__file__), 'instance', 'lab_manager.db')

if not os.path.exists(db_path):
    print(f"❌ База данных не найдена: {db_path}")
    exit(1)

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Проверяем, есть ли уже колонка test_type
cursor.execute("PRAGMA table_info(test)")
columns = [row[1] for row in cursor.fetchall()]

if 'test_type' in columns:
    print("✅ Колонка test_type уже существует, миграция не нужна.")
else:
    cursor.execute("ALTER TABLE test ADD COLUMN test_type VARCHAR(10) DEFAULT 'kr'")
    conn.commit()
    print("✅ Колонка test_type добавлена. Все существующие записи получили значение 'kr'.")

conn.close()
print("✅ Миграция завершена!")
