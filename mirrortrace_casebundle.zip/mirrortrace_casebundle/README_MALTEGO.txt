Recommended workflow:
1. Start from 10_datasets/seeds.txt.
2. Import 10_datasets/graph_nodes.csv and 10_datasets/graph_edges.csv into your graph workflow.
3. Use 10_datasets/capture_index.csv to pivot from nodes to local captures and files.
4. Inspect PDF content, PDF metadata, and developer traces before deciding which identity belongs to the retained responder copy.

The bundle is intentionally noisy.
More than one real-looking identity is present.
